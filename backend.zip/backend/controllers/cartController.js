
const asyncHandler = require('express-async-handler');
// const cartModels = require('../models/cartModels.js');

const Cart = require('../models/cartModels.js');

// const addCart = asyncHandler(async (req, res) => {

//   try {
//     const { nickName, petType, price, age } = req.body;
//     const cart = await Cart.create({
//       nickName,
//       petType,
//       price,
//       age,
//     });

//     console.log("=========req body", req.body);
//     const createdCart = await cart.save();
//     res.status(201).json(createdCart);
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ message: 'Cart creation failed.' });
//   }
// });

const fs = require('fs');

// const addCart = asyncHandler(async (req, res) => {
//   try {
//     const { nickName, petType, price, age, image } = req.body;

//     // Process the image data and save it to the appropriate location
//     const base64Image = image.split(';base64,').pop();
//     const imageExtension = image.split(';')[0].split('/')[1];
//     const imagePath = `uploads/${Date.now()}-${Math.round(Math.random() * 1e9)}.${imageExtension}`;

//     fs.writeFile(imagePath, base64Image, { encoding: 'base64' }, async function (err) {
//       if (err) {
//         res.status(400);
//         throw new Error('Error occurred while saving the image');
//       }

//       const cart = await Cart.create({
//         nickName,
//         petType,
//         price,
//         age,
//         image: imagePath, // Store the image path in the database
//       });

//       const createdCart = await cart.save();
//       res.status(201).json(createdCart);
//     });
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ message: 'Cart creation failed.' });
//   }
// });

// const addCart = asyncHandler(async (req, res) => {
//   try {
//     const { nickName, petType, price, age, image } = req.body;

//     // Process the image data and save it to the appropriate location
//     const base64Image = image.split(';base64,').pop();
//     const imageExtension = image.split(';')[0].split('/')[1];
//     const imagePath = `uploads/${Date.now()}-${Math.round(Math.random() * 1e9)}.${imageExtension}`;

//     fs.writeFile(imagePath, base64Image, { encoding: 'base64' }, async function (err) {
//       if (err) {
//         res.status(400);
//         throw new Error('Error occurred while saving the image');
//       }

//       const cart = await Cart.create({
//         nickName,
//         petType,
//         price,
//         age,
//         image: imagePath, // Store the image path in the database
//       });

//       const createdCart = await cart.save();
//       res.status(201).json(createdCart);
//     });
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ message: 'Cart creation failed.' });
//   }
// });

const addCart = asyncHandler(async (req, res) => {
  try {
    const { nickName, petType, price, age, image } = req.body;

    // Process the image data and save it to the appropriate location
    const base64Image = image.split(';base64,').pop();
    const imageExtension = image.split(';')[0].split('/')[1];
    const timestamp = Date.now();
    const randomNumber = Math.round(Math.random() * 1e9);
    const imageName = `${timestamp}-${randomNumber}.${imageExtension}`;
    const correctedImageName = `${timestamp}-${randomNumber}_${imageExtension}`;
    const imagePath = `uploads/${correctedImageName}`;

    fs.writeFile(imagePath, base64Image, { encoding: 'base64' }, async function (err) {
      if (err) {
        res.status(400);
        throw new Error('Error occurred while saving the image');
      }

      const cart = await Cart.create({
        nickName,
        petType,
        price,
        age,
        image: imagePath, // Store the image path in the database
      });

      const createdCart = await cart.save();
      res.status(201).json(createdCart);
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Cart creation failed.' });
  }
});





const getCart = async (req, res) => {
  try {
    const cartData = await Cart.find()
    res.status(200).json({ data: cartData })
  } catch (error) {
    res.status(404).json({ message: error.message })
  }
}

const deleteCart = asyncHandler(async (req, res) => {
  const { id } = req.params;
  console.log("============", id);
  try {
    const cart = await Cart.findById(id);
    console.log("=======here is cart ", cart);
    if (cart) {
      await Cart.findByIdAndRemove(id);
      res.json({ message: 'Cart item deleted' });
    } else {
      res.status(401).json({ message: 'Cart item not found' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Cart deletion failed.' });
  }
});

module.exports = { addCart, getCart, deleteCart };

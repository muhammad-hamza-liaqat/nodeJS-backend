// const Pet = require('../models/petModels.js');
// const asyncHandler = require('express-async-handler');
// const petModels = require('../models/petModels.js');
// const multer = require('../middleware/multer.js')
// const upload = require('../middleware/multer.js')
// const addPet = asyncHandler(async (req, res) => {
//     // const {
//     //     nickName, petType, gender, price, color,
//     //     age, group, training, energy, grooming,
//     //     remarks, phoneNo, address, image
//     // } = req.body;
//     const {
//         nickName, petType, gender, price, color,
//         age, group, training, energy, grooming,
//         remarks, phoneNo, address
//     } = req.body;


//     if (!nickName || !petType || !gender || !price || !color || !age || !group || !training || !energy || !grooming || !remarks || !phoneNo || !image || !address) {
//         res.status(400);
//         throw new Error("All Fields To Fill Is Mendatory........");
//     }

//     // const path = require("path");
//     // const imagePath = path.join(__dirname, "..", "uploads");

//     const pet = await Pet.create({

//         nickName,
//         petType,
//         gender,
//         price,
//         color,
//         age,
//         group,
//         training,
//         energy,
//         grooming,
//         remarks,
//         // imageUpload,
//         // image: imagePath,
//         image,
//         // image: Image.create({ image: base64 }).then(()=>{res.send({status:"okay"})}).then(()=>{res.send({status:"error" , data:error})}),
//         phoneNo,
//         address
//     });
//     console.log("=========req body", req.body);
//     const createdPet = await pet.save();
//     res.status(201).json(createdPet);
// });

const petModels = require('../models/petModels.js');
const Pet = require('../models/petModels.js');
const asyncHandler = require('express-async-handler');
const fs = require('fs');

const addPet = asyncHandler(async (req, res) => {
  // Handle other form data
  const {
    nickName, petType, gender, price, color,
    age, group, training, energy, grooming,
    remarks, phoneNo, address,
    image // Base64 encoded image data
  } = req.body;

  // Decode base64 image data and save it to a file
  const base64Image = image.split(';base64,').pop();
  const imageExtension = image.split(';')[0].split('/')[1];
  const imagePath = `uploads/${Date.now()}-${Math.round(Math.random() * 1e9)}.${imageExtension}`;

  fs.writeFile(imagePath, base64Image, { encoding: 'base64' }, async function (err) {
    if (err) {
      res.status(400);
      throw new Error('Error occurred while saving the image');
    }

    // Create the pet object with image and other form data
    const pet = await Pet.create({
      nickName,
      petType,
      gender,
      price,
      color,
      age,
      group,
      training,
      energy,
      grooming,
      remarks,
      image: imagePath, // Store the image path in the database
      phoneNo,
      address
    });

    console.log("=========req body", req.body);
    const createdPet = await pet.save();
    res.status(201).json(createdPet);
  });
});

module.exports = { addPet };








const getPet = async (req, res) => {
    try {
        const petData = await petModels.find()
        res.status(200).json({ data: petData })
    } catch (error) {
        res.status(404).json({ message: error.message })
    }
}

const singlePet = async (req, res) => {
    Pet.findById(req.params.id).then((singleData) => {
        if (!singleData) {
            return res.status(404).send();
        }
        res.send(singleData)
    }).catch((error) => {
        res.status(500).send(error)
    })
}

module.exports = { addPet, getPet, singlePet };

